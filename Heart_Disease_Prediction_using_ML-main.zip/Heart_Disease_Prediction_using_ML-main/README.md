# Heart_Disease_Prediction_using_ML
In this project we are trying to predict if a person is at a risk of heart disease.


**INFO**

This Project is trained on cleaned dataset i.e. heart.csv.

**Future Work**

Have to make a seperate ipynb and use Heart_strokes data to predict.

**Challanges**

smoking habits attribute have more than 50% data as missing.
